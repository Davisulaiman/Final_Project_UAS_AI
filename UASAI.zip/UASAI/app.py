from flask import Flask, request, render_template
import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, precision_score, recall_score
import io
import base64

app = Flask(__name__)

# Load the model
model_path = '/mnt/data/PredictiveMaintenanceAircraft.keras'

# Dummy data for example
sequence_length = 50
nb_features = 27  # Update the number of features
nb_out = 1

# Generate random data for example
seq_array = np.random.rand(1000, sequence_length, nb_features)
label_array = np.random.randint(2, size=(1000, nb_out))

# Function to evaluate the model
def evaluate_model(model, seq_array, label_array):
    scores = model.evaluate(seq_array, label_array, verbose=1, batch_size=200)
    y_pred = (model.predict(seq_array) > 0.5).astype("int32")
    y_true = label_array

    cm = confusion_matrix(y_true, y_pred)
    precision = precision_score(y_true, y_pred)
    recall = recall_score(y_true, y_pred)
    f1 = 2 * (precision * recall) / (precision + recall)

    return scores[1], cm, precision, recall, f1

def plot_confusion_matrix(cm):
    plt.figure(figsize=(10, 7))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=[0, 1], yticklabels=[0, 1])
    plt.xlabel('True Labels')
    plt.ylabel('Predicted Labels')
    plt.title('Confusion Matrix')
    buf = io.BytesIO()
    plt.savefig(buf, format='png')
    buf.seek(0)
    return base64.b64encode(buf.getvalue()).decode('utf8')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Get feature data from the form
        features = [
            float(request.form['id']),
            float(request.form['cycle']),
            float(request.form['RUL']),
            float(request.form['label1']),
            float(request.form['label2']),
            float(request.form['s1']),
            float(request.form['s10']),
            float(request.form['s11']),
            float(request.form['s12']),
            float(request.form['s13']),
            float(request.form['s14']),
            float(request.form['s15']),
            float(request.form['s16']),
            float(request.form['s17']),
            float(request.form['s18']),
            float(request.form['s19']),
            float(request.form['s20']),
            float(request.form['s21']),
            float(request.form['s3']),
            float(request.form['s4']),
            float(request.form['s5']),
            float(request.form['s6']),
            float(request.form['s7']),
            float(request.form['s8']),
            float(request.form['s9']),
            float(request.form['setting1']),
            float(request.form['setting2']),
            float(request.form['setting3'])
        ]
        
        # Convert features to tensor and reshape if necessary
        input_data = tf.convert_to_tensor([features], dtype=tf.float32)
        
        # Make prediction
        prediction = model.predict(input_data)
        
        # Assuming model output needs to be converted to a list or other format
        output = prediction[0].tolist()
        
        return render_template('index.html', prediction=output)
    except ValueError as ve:
        # Handle conversion error and provide error message
        error_message = f"Invalid input: {str(ve)}. Please enter numeric values for all fields."
        return render_template('index.html', error=error_message)
    except Exception as e:
        # Handle other errors
        error_message = f"An error occurred: {str(e)}"
        return render_template('index.html', error=error_message)

@app.route('/summary')
def summary():
    try:
        training_accuracy, cm, precision, recall, f1 = evaluate_model(model, seq_array, label_array)
        cm_image = plot_confusion_matrix(cm)
        
        return render_template('summary.html', training_accuracy=training_accuracy, precision=precision, recall=recall, f1=f1, cm_image=cm_image)
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    app.run(debug=True)
